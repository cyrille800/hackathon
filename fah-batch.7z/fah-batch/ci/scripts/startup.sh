#!/bin/sh
ShellPath=$(dirname $0)
certPath=$ShellPath/certificats

echo "${REMOTE_CA_HOSTS}" | tr "," "\n" > ${certPath}/.hosts
cat ${certPath}/.hosts
if [ ! -f "${certPath}/startup.log" ]; then
    echo " --> Collect certificats"
    cd "${certPath}" || exit 1
        rm -f ./*.crt
        while read -r certHost; do
            echo | openssl s_client -showcerts -connect "${certHost}" 2>/dev/null \
                | awk -v certHost=${certHost} '/BEGIN/ { i++; } /BEGIN/, /END/ { print > "cert-" certHost "-" i ".crt" }'
        done < ${certPath}/.hosts
        for file in *.crt; do
            keytool -importcert -cacerts -keypass changeit -file "${file}" -noprompt -storepass changeit -alias "${file}" | tee -a  "${certPath}/startup.log"
        done
    cd - || exit 1
    echo "Java SSL certificates installed ..."
fi

if [ $# -eq 0 ]; then
    tail -f /dev/null
else
    java -jar "${@}"
    exit $?
fi
