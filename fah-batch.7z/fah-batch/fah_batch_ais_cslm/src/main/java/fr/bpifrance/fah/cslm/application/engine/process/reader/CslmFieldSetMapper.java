package fr.bpifrance.fah.cslm.application.engine.process.reader;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgModel;

import java.time.ZoneId;

public class CslmFieldSetMapper implements FieldSetMapper<CSLMPerCompaCtgModel> {

    @Override
    public CSLMPerCompaCtgModel mapFieldSet(FieldSet fieldSet) throws BindException {
        CSLMPerCompaCtgModel res = new CSLMPerCompaCtgModel();
        res.setDCompta(fieldSet.readDate(0).toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        res.setCEntityGestOseo(fieldSet.readString(1));
        res.setCCleCmpta(fieldSet.readString(2));
        res.setCEnttJuri(fieldSet.readString(3));
        res.setNCren(fieldSet.readInt(4));
        res.setNCrenOrdre(fieldSet.readInt(5));
        res.setCSensMntCompta(fieldSet.readString(6));
        res.setCSystInfqAlimSystCompta(fieldSet.readString(7));
        res.setCprogSource(fieldSet.readString(8));
        res.setCComplCle(fieldSet.readString(9));
        res.setLMeSlm(fieldSet.readString(10));
        return res;
    }

}
