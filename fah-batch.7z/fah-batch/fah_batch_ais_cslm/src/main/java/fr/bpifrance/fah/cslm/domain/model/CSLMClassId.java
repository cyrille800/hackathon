package fr.bpifrance.fah.cslm.domain.model;

import java.time.LocalDate;
import java.util.Objects;

public class CSLMClassId {

    private LocalDate dCompta;

    private String cEntityGestOseo;

    private String cCleCmpta;

    private String cEnttJuri;

    private Integer nCren;

    private Integer nCrenOrdre;

    private String cSensMntCompta;

    private String cSystInfqAlimSystCompta;

    private String cprogSource;

    private String cComplCle;

    public CSLMClassId() {
    }

    public CSLMClassId(LocalDate dCompta, String cEntityGestOseo, String cCleCmpta, String cEnttJuri, Integer nCren, Integer nCrenOrdre, String cSensMntCompta, String cSystInfqAlimSystCompta, String cprogSource, String cComplCle) {
        this.dCompta = dCompta;
        this.cEntityGestOseo = cEntityGestOseo;
        this.cCleCmpta = cCleCmpta;
        this.cEnttJuri = cEnttJuri;
        this.nCren = nCren;
        this.nCrenOrdre = nCrenOrdre;
        this.cSensMntCompta = cSensMntCompta;
        this.cSystInfqAlimSystCompta = cSystInfqAlimSystCompta;
        this.cprogSource = cprogSource;
        this.cComplCle = cComplCle;
    }

    @Override
    public int hashCode() {
        return Objects.hash(dCompta, cEntityGestOseo, cCleCmpta, cEnttJuri, nCren, nCrenOrdre, cSensMntCompta, cSystInfqAlimSystCompta, cprogSource, cComplCle);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CSLMClassId other = (CSLMClassId) obj;
        return Objects.equals(dCompta, other.dCompta) && Objects.equals(cEntityGestOseo, other.cEntityGestOseo)
                && Objects.equals(cCleCmpta, other.cCleCmpta) && Objects.equals(cEnttJuri, other.cEnttJuri) && Objects.equals(nCren, other.nCren)
                && Objects.equals(nCrenOrdre, other.nCrenOrdre) && Objects.equals(cSensMntCompta, other.cSensMntCompta) && Objects.equals(cSystInfqAlimSystCompta, other.cSystInfqAlimSystCompta)
                && Objects.equals(cprogSource, other.cprogSource) && Objects.equals(cComplCle, other.cComplCle);
    }
}
