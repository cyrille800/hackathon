package fr.bpifrance.fah.cslm.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class CSLMPerCompaCtgModel {


    private LocalDate dCompta;

    private String cEntityGestOseo;

    private String cCleCmpta;

    private String cEnttJuri;

    private Integer nCren;

    private Integer nCrenOrdre;

    private String cSensMntCompta;

    private String cSystInfqAlimSystCompta;

    private String cprogSource;

    private String cComplCle;

    private String lMeSlm;

    private String cMe;


}
