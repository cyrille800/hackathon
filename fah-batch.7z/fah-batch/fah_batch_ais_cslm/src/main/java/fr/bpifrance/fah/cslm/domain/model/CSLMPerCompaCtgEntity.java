package fr.bpifrance.fah.cslm.domain.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Setter;

@Setter
@Entity
@Table(name = "CSLM_CLE_ME_SLM")

@IdClass(CSLMClassId.class)
public class CSLMPerCompaCtgEntity {

    @Id
    @Column(name = "D_COMPTA")
    private LocalDate dCompta;

    @Id
    @Column(name = "C_ENTITE_GEST_OSEO")
    private String cEntityGestOseo;

    @Id
    @Column(name = "C_CLE_CMPTA")
    private String cCleCmpta;

    @Id
    @Column(name = "C_ENTT_JURI")
    private String cEnttJuri;

    @Id
    @Column(name = "N_CREN")
    private Integer nCren;

    @Id
    @Column(name = "N_CREN_ORDRE")
    private Integer nCrenOrdre;

    @Id
    @Column(name = "C_SENS_MNT_COMPTA")
    private String cSensMntCompta;

    @Id
    @Column(name = "C_SYST_INFQ_ALIM_SYST_COMPTA")
    private String cSystInfqAlimSystCompta;

    @Id
    @Column(name = "C_PROG_SOURCE")
    private String cProgSource;

    @Id
    @Column(name = "C_COMPL_CLE")
    private String cComplCle;

    @Column(name = "L_ME_SLM")
    private String lMeSlm;

}
