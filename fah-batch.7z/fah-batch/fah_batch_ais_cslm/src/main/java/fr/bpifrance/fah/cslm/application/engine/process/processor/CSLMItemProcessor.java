package fr.bpifrance.fah.cslm.application.engine.process.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import fr.bpifrance.fah.cslm.application.engine.service.CSLMTransformerService;
import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgEntity;
import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgModel;

/**
 * @author M03935
 */
public class CSLMItemProcessor implements ItemProcessor<CSLMPerCompaCtgModel, CSLMPerCompaCtgEntity> {

    private static final Logger logger = LoggerFactory.getLogger(CSLMItemProcessor.class);

    private final CSLMTransformerService transformService;

    public CSLMItemProcessor(CSLMTransformerService transformService) {
        this.transformService = transformService;
    }


    @Override
    public CSLMPerCompaCtgEntity process(CSLMPerCompaCtgModel input) {
        try {
            CSLMPerCompaCtgEntity transformedInput = transformService.transform(input);
            return transformedInput;
        } catch (Exception e) {
            logger.error("Error processing line: {}", input, e);
            throw new RuntimeException("Error processing line: " + input, e);
        }
    }

}
