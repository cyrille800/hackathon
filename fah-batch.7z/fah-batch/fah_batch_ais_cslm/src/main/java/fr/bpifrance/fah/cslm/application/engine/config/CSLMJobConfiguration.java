package fr.bpifrance.fah.cslm.application.engine.config;

import fr.bpifrance.fah.cslm.application.engine.process.processor.CSLMItemProcessor;
import fr.bpifrance.fah.cslm.application.engine.process.reader.CSLMItemReader;
import fr.bpifrance.fah.cslm.application.engine.process.writer.CSLMItemWriter;
import fr.bpifrance.fah.cslm.application.engine.service.CSLMTransformerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;

import fr.bpifrance.fah.cslm.application.engine.process.listener.CSLMJobExecutionListenner;
import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgEntity;
import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgModel;
import fr.bpifrance.fah.cslm.domain.repository.CSLMPerCompaCtgRepository;

/**
 * @author M80889
 */
public class CSLMJobConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(CSLMJobConfiguration.class);

    @Value("${batch.chunk.size}")
    private String chunkSize;

    @Value("${batch.input.filepath}")
    private String inputFilePath;


    @Autowired
    private CSLMTransformerService transformService;

    @Autowired
    private CSLMPerCompaCtgRepository repository;

    @Bean
    public Job job(JobRepository jobRepository, Step step) {
        logger.info("Creating job with name 'cslm-job'");
        return new JobBuilder("cslm-job", jobRepository)
                .start(step)
                .listener(jobExecutionListener())
                .build();
    }

    @Bean
    public Step step(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        logger.info("Creating step with chunk size {}", chunkSize);
        return new StepBuilder("step", jobRepository)
                .<CSLMPerCompaCtgModel, CSLMPerCompaCtgEntity>chunk(Integer.parseInt(chunkSize), transactionManager)
                .reader(itemReader())
                .processor(itemProcessor())
                .writer(itemWriter())
                .build();
    }

    @Bean
    public FlatFileItemReader<CSLMPerCompaCtgModel> itemReader() {
        logger.info("Creating item reader for file {}", inputFilePath);
        return new CSLMItemReader(new FileSystemResource(inputFilePath));
    }

    @Bean
    public ItemProcessor<CSLMPerCompaCtgModel, CSLMPerCompaCtgEntity> itemProcessor() {
        logger.info("Creating item processor");
        return new CSLMItemProcessor(transformService);
    }

    @Bean
    public ItemWriter<CSLMPerCompaCtgEntity> itemWriter() {
        logger.info("Creating item writer");
        return new CSLMItemWriter(repository);
    }


    @Bean
    public JobExecutionListener jobExecutionListener() {
        return new CSLMJobExecutionListenner();
    }

}
