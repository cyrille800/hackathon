package fr.bpifrance.fah.cslm.application.engine.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgEntity;
import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgModel;

/**
 * @author M03935
 */
@Service
public class CSLMTransformerService {

    private static final Logger logger = LogManager.getLogger(CSLMTransformerService.class);


    /**
     * @return the transformed CslmPerCompaCtgEntity
     */
    public CSLMPerCompaCtgEntity transform(CSLMPerCompaCtgModel input) {
        CSLMPerCompaCtgEntity res = new CSLMPerCompaCtgEntity();
        res.setDCompta(input.getDCompta());
        res.setCCleCmpta(input.getCCleCmpta());
        res.setCEnttJuri(input.getCEnttJuri());
        res.setCSystInfqAlimSystCompta(input.getCSystInfqAlimSystCompta());
        res.setCProgSource(input.getCprogSource());
        res.setCProgSource("ZZZZZZZZZZZZZZZZZZZZ");

        String C_ENTITE_GEST_OSEO = input.getCEntityGestOseo();
        res.setCEntityGestOseo((C_ENTITE_GEST_OSEO == null || C_ENTITE_GEST_OSEO.trim().isEmpty()) ? "___" : C_ENTITE_GEST_OSEO);

        Integer N_CREN = input.getNCren();
        res.setNCren((N_CREN == null) ? 0 : N_CREN);

        Integer N_CREN_ORDRE = input.getNCrenOrdre();
        res.setNCrenOrdre((N_CREN_ORDRE == null) ? 0 : N_CREN_ORDRE);

        String C_SENS_MNT_COMPTA = input.getCSensMntCompta();
        res.setCSensMntCompta((C_SENS_MNT_COMPTA == null || C_SENS_MNT_COMPTA.trim().isEmpty()) ? "_" : C_SENS_MNT_COMPTA);

        String C_ME = input.getCMe();
        String C_COMPL_CLE = (C_ME == null || C_ME.trim().isEmpty())
                ? "XXXXXXXXXXXXXXXXXXXX"
                : String.format("%-20s", C_ME).replace(' ', 'X');

        res.setCComplCle(C_COMPL_CLE);

        return res;
    }
}