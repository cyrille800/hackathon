package fr.bpifrance.fah.cslm.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgEntity;

@Repository
public interface CSLMPerCompaCtgRepository extends JpaRepository<CSLMPerCompaCtgEntity, Long> {

}
