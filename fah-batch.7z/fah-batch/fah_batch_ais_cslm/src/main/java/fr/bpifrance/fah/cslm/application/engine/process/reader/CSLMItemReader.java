package fr.bpifrance.fah.cslm.application.engine.process.reader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.core.io.Resource;

import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgModel;

/**
 * @author M03935
 */
public class CSLMItemReader extends FlatFileItemReader<CSLMPerCompaCtgModel> {

    private static final Logger logger = LoggerFactory.getLogger(CSLMItemReader.class);


    public CSLMItemReader(Resource inputFile) {
        this.setResource(inputFile);
        DefaultLineMapper<CSLMPerCompaCtgModel> lineMapper = new DefaultLineMapper<>();
        DelimitedLineTokenizer delimitedLineTokenizer = new DelimitedLineTokenizer();
        delimitedLineTokenizer.setDelimiter(";");
        lineMapper.setLineTokenizer(delimitedLineTokenizer);
        lineMapper.setFieldSetMapper(new CslmFieldSetMapper());
        this.setLineMapper(lineMapper);
    }


}

