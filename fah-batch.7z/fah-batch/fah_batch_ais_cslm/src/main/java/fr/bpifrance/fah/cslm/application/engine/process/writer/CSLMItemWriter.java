package fr.bpifrance.fah.cslm.application.engine.process.writer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;

import fr.bpifrance.fah.cslm.application.engine.process.processor.CSLMItemProcessor;
import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgEntity;
import fr.bpifrance.fah.cslm.domain.repository.CSLMPerCompaCtgRepository;

/**
 * @author M03935
 */
public class CSLMItemWriter implements ItemWriter<CSLMPerCompaCtgEntity> {

    private static final Logger logger = LoggerFactory.getLogger(CSLMItemProcessor.class);

    private CSLMPerCompaCtgRepository repository;

    public CSLMItemWriter(CSLMPerCompaCtgRepository repository) {
        this.repository = repository;
    }


    @Override
    public void write(Chunk<? extends CSLMPerCompaCtgEntity> items) throws Exception {
        repository.saveAll(items);
    }

}
