package fr.bpifrance.fah.cslm.domain.model;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class CSLMClassIdTest {

    @Test
    public void equalsWithSameObject() {
        CSLMClassId id1 = new CSLMClassId(LocalDate.parse("10/02/2025", DateTimeFormatter.ofPattern("dd/MM/yyyy")),"003","EUR388900R100 004EUR4","00003", (int) 21210.,(int) 3.,"C","V","VLT","07");
        assertTrue(id1.equals(id1));
    }

    @Test
    public void equalsWithNullObject() {
        CSLMClassId id1 = new CSLMClassId(LocalDate.parse("10/02/2025", DateTimeFormatter.ofPattern("dd/MM/yyyy")),"003","EUR388900R100 004EUR4","00003", (int) 21210.,(int) 3.,"C","V","VLT","07");
        assertFalse(id1.equals(null));
    }

    @Test
    public void equalsWithDifferentClassObject() {
        CSLMClassId id1 = new CSLMClassId(LocalDate.parse("10/02/2025", DateTimeFormatter.ofPattern("dd/MM/yyyy")),"003","EUR388900R100 004EUR4","00003", (int) 21210.,(int) 3.,"C","V","VLT","07");
        String other = "SomeString";
        assertFalse(id1.equals(other));
    }

    @Test
    public void equalsWithEqualObjects() {
        CSLMClassId id1 = new CSLMClassId(LocalDate.parse("10/02/2025", DateTimeFormatter.ofPattern("dd/MM/yyyy")),"003","EUR388900R100 004EUR4","00003", (int) 21210.,(int) 3.,"C","V","VLT","07");
        CSLMClassId id2 = new CSLMClassId(LocalDate.parse("10/02/2025", DateTimeFormatter.ofPattern("dd/MM/yyyy")),"003","EUR388900R100 004EUR4","00003", (int) 21210.,(int) 3.,"C","V","VLT","07");
        assertTrue(id1.equals(id2));
    }

    @Test
    public void equalsWithDifferentNomLivre() {
        CSLMClassId id1 = new CSLMClassId(LocalDate.parse("10/02/2025", DateTimeFormatter.ofPattern("dd/MM/yyyy")),"003","EUR388900R100 004EUR4","00003", (int) 21210.,(int) 3.,"C","V","VLT","07");
        CSLMClassId id2 = new CSLMClassId(LocalDate.parse("11/02/2025", DateTimeFormatter.ofPattern("dd/MM/yyyy")),"003","EUR388900R100 004EUR4","00003", (int) 21210.,(int) 3.,"C","V","VLT","07");
        assertFalse(id1.equals(id2));
    }

    /*
    @Test
    public void equalsWithDifferentPerCompta() {
        CSLMClassId id1 = new CSLMClassId("Livre1", 1, 2023);
        CSLMClassId id2 = new CSLMClassId("Livre1", 2, 2023);
        assertFalse(id1.equals(id2));
    }

    @Test
    public void equalsWithDifferentAnPerCompta() {
        CSLMClassId id1 = new CSLMClassId("Livre1", 1, 2023);
        CSLMClassId id2 = new CSLMClassId("Livre1", 1, 2024);
        assertFalse(id1.equals(id2));
    }

    @Test
    public void hashCodeWithEqualObjects() {
        CSLMClassId id1 = new CSLMClassId("Livre1", 1, 2023);
        CSLMClassId id2 = new CSLMClassId("Livre1", 1, 2023);
        assertEquals(id1.hashCode(), id2.hashCode());
    }

    @Test
    public void hashCodeWithDifferentObjects() {
        CSLMClassId id1 = new CSLMClassId("Livre1", 1, 2023);
        CSLMClassId id2 = new CSLMClassId("Livre2", 2, 2024);
        assertNotEquals(id1.hashCode(), id2.hashCode());
    }*/
}