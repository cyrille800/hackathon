package fr.bpifrance.fah.cslm.application.engine.process;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import fr.bpifrance.fah.cslm.application.engine.process.processor.CSLMItemProcessor;
import fr.bpifrance.fah.cslm.application.engine.service.CSLMTransformerService;
import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgEntity;
import fr.bpifrance.fah.cslm.domain.model.CSLMPerCompaCtgModel;

public class CSLMItemProcessorTest {

    @Mock
    private CSLMTransformerService transformService;

    @InjectMocks
    private CSLMItemProcessor processor;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void processShouldTransformInputSuccessfully() throws Exception {
        CSLMPerCompaCtgModel input = new CSLMPerCompaCtgModel();
        CSLMPerCompaCtgEntity expectedOutput = new CSLMPerCompaCtgEntity();
        when(transformService.transform(input)).thenReturn(expectedOutput);

        CSLMPerCompaCtgEntity result = processor.process(input);

        assertNotNull(result);
        assertEquals(expectedOutput, result);
    }

    @Test
    public void processShouldThrowRuntimeExceptionOnTransformationError() throws Exception {
        CSLMPerCompaCtgModel input = new CSLMPerCompaCtgModel();
        when(transformService.transform(input)).thenThrow(new RuntimeException("Transformation error"));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> processor.process(input));

        assertEquals("Error processing line: " + input, exception.getMessage());
    }
}
