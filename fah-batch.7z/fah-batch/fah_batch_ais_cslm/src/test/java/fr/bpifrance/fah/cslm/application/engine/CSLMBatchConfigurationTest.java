package fr.bpifrance.fah.cslm.application.engine;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;

import com.zaxxer.hikari.HikariDataSource;

import fr.bpifrance.fah.cslm.application.engine.config.CSLMBatchConfiguration;

public class CSLMBatchConfigurationTest {

    @Mock
    private CSLMBatchConfiguration config;

    @InjectMocks
    private CSLMBatchConfigurationTest CSLMBatchConfigurationTest;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void H2DatasourceShouldReturnEmbeddedDatabase() {
        DataSource mockDataSource = mock(org.springframework.jdbc.datasource.embedded.EmbeddedDatabase.class);
        when(config.H2Datasource()).thenReturn(mockDataSource);

        DataSource dataSource = config.H2Datasource();
        assertNotNull(dataSource);
        assertTrue(dataSource instanceof org.springframework.jdbc.datasource.embedded.EmbeddedDatabase);
    }

    @Test
    public void oracleDatasourcePropertiesShouldReturnDataSourceProperties() {
        DataSourceProperties mockProperties = mock(DataSourceProperties.class);
        when(mockProperties.getDriverClassName()).thenReturn("oracle");
        when(config.oracleDatasourceProperties()).thenReturn(mockProperties);

        DataSourceProperties properties = config.oracleDatasourceProperties();
        assertNotNull(properties);
        assertEquals("oracle", properties.getDriverClassName());
    }

    @Test
    public void oracleDatasourceShouldReturnHikariDataSource() {
        HikariDataSource mockDataSource = mock(HikariDataSource.class);
        when(config.oracleDatasource()).thenReturn(mockDataSource);

        DataSource dataSource = config.oracleDatasource();
        assertNotNull(dataSource);
        assertTrue(dataSource instanceof HikariDataSource);
    }

    @Test
    public void oracleDatasourceShouldHaveCorrectProperties() {
        HikariDataSource mockDataSource = mock(HikariDataSource.class);
        when(mockDataSource.getJdbcUrl()).thenReturn("jdbc:oracle:thin:@localhost:1521:xe");
        when(mockDataSource.getUsername()).thenReturn("username");
        when(mockDataSource.getPassword()).thenReturn("password");
        when(config.oracleDatasource()).thenReturn(mockDataSource);

        HikariDataSource dataSource = (HikariDataSource) config.oracleDatasource();
        assertEquals("username", dataSource.getUsername());
        assertEquals("password", dataSource.getPassword());
    }
}