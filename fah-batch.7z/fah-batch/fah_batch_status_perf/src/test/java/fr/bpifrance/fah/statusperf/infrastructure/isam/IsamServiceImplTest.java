package fr.bpifrance.fah.statusperf.infrastructure.isam;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import fr.bpifrance.fah.statusperf.infrastructure.isam.model.IsamAccessToken;
import fr.bpifrance.fah.statusperf.infrastructure.isam.service.impl.IsamServiceImpl;

class IsamServiceImplTest {

    @Mock
    private IsamRestClient isamRestClient;


    @InjectMocks
    private IsamServiceImpl isamServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void retrieveAccessToken_whenSuccessful_shouldReturnAccessToken() {
        IsamAccessToken mockToken = new IsamAccessToken();
        ResponseEntity<IsamAccessToken> responseEntity = ResponseEntity.ok(mockToken);
        when(isamRestClient.retrieveAccessToken(anyMap())).thenReturn(responseEntity);

        IsamAccessToken result = isamServiceImpl.retrieveAccessToken();

        assertNotNull(result);
        assertEquals(mockToken, result);
    }

    @Test
    void retrieveAccessToken_whenExceptionThrown_shouldReturnNull() {
        when(isamRestClient.retrieveAccessToken(anyMap())).thenThrow(new RuntimeException("Error"));

        IsamAccessToken result = isamServiceImpl.retrieveAccessToken();

        assertNull(result);
    }

    @Test
    void retrieveAccessToken_whenResponseBodyIsNull_shouldReturnNull() {
        ResponseEntity<IsamAccessToken> responseEntity = ResponseEntity.ok(null);
        when(isamRestClient.retrieveAccessToken(anyMap())).thenReturn(responseEntity);

        IsamAccessToken result = isamServiceImpl.retrieveAccessToken();

        assertNull(result);
    }
}
