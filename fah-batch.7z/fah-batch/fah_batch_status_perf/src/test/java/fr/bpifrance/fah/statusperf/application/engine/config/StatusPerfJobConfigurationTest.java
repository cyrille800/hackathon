package fr.bpifrance.fah.statusperf.application.engine.config;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.transaction.PlatformTransactionManager;

import fr.bpifrance.fah.statusperf.application.engine.process.reader.StatusPerfItemReader;

public class StatusPerfJobConfigurationTest {

    private StatusPerfJobConfiguration configuration;
    private JobRepository jobRepository;
    private PlatformTransactionManager transactionManager;
    private Step step;

    @BeforeEach
    void setUp() {
        configuration = new StatusPerfJobConfiguration();
        jobRepository = mock(JobRepository.class);
        transactionManager = mock(PlatformTransactionManager.class);
        step = mock(Step.class);
    }

    @Test
    void jobBeanCreation() {
        Job job = configuration.job(jobRepository, step);
        assertNotNull(job);
    }

    @Test
    void stepBeanCreation() {
        Step step = configuration.step(jobRepository, transactionManager);
        assertNotNull(step);
    }

    @Test
    void itemReaderBeanCreation() {
        StatusPerfItemReader itemReader = configuration.itemReader();
        assertNotNull(itemReader);
    }

}
