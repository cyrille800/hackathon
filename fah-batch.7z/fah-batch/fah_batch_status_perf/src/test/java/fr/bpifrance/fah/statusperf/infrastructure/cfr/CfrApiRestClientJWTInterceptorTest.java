package fr.bpifrance.fah.statusperf.infrastructure.cfr;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import feign.FeignException;
import feign.RequestTemplate;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.interceptors.CfrApiRestClientJWTInterceptor;
import fr.bpifrance.fah.statusperf.infrastructure.isam.model.IsamAccessToken;
import fr.bpifrance.fah.statusperf.infrastructure.isam.service.api.IsamService;

@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
@ContextConfiguration(loader=AnnotationConfigContextLoader.class)
class CfrApiRestClientJWTInterceptorTest {

	@Mock
	IsamService isamService;
	@InjectMocks
	CfrApiRestClientJWTInterceptor cfrApiRestClientJWTInterceptor;

	@Test
	@DisplayName("CFR Rest Client JWT Interceptor Test")
	void testApply() {
		Exception exception = null;
		try {
			var template = new RequestTemplate();
			Mockito.when(isamService.retrieveAccessToken()).thenReturn(new IsamAccessToken());
			cfrApiRestClientJWTInterceptor.apply(template);
		} catch (Exception e) {
			exception = e;
		}
		assertNull(exception);
	}

	@Test
	@DisplayName("CFR Rest Client JWT Interceptor Test Exception")
	void testApplyException() {
		var template = new RequestTemplate();
		Mockito.when(isamService.retrieveAccessToken()).thenThrow(FeignException.class);
		assertThrows(FeignException.class, () -> cfrApiRestClientJWTInterceptor.apply(template));
	}
}
