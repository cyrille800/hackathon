package fr.bpifrance.fah.statusperf.domain.utils;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

class FileUtilsTest {

    private Path testPath;
    private String permissions;

    @BeforeEach
    void setUp() {
        testPath = Paths.get("/tmp/testdir");
        permissions = "rwxr-x---";
    }


    @Test
    void createDirectories_whenPathIsNull_shouldThrowException() {
        assertThrows(NullPointerException.class, () -> FileUtils.createDirectories(null, permissions));
    }

    @Test
    void createDirectories_whenPermissionsAreNull_shouldThrowException() {
        assertThrows(NullPointerException.class, () -> FileUtils.createDirectories(testPath, null));
    }


    @Test
    void createFile_whenPathIsNull_shouldThrowException() {
        assertThrows(NullPointerException.class, () -> FileUtils.createFile(null, permissions));
    }

    @Test
    void createFile_whenPermissionsAreNull_shouldThrowException() {
        assertThrows(NullPointerException.class, () -> FileUtils.createFile(testPath, null));
    }


    @Test
    void delete_whenPathIsNull_shouldThrowException() {
        assertThrows(NullPointerException.class, () -> FileUtils.delete(null));
    }
}
