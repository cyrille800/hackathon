package fr.bpifrance.fah.statusperf.common;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import fr.bpifrance.fah.statusperf.common.exceptions.BusinessError;
import fr.bpifrance.fah.statusperf.common.exceptions.BusinessException;

class BusinessExceptionTest {

	private final String CFR_CALL_ERROR_CODE = "fah.cfr.api";
	private BusinessException businessException = null;



	@Test
	void testWithThrowbleException() {
		var message = CFR_CALL_ERROR_CODE;
		BusinessError businessError = new BusinessError(message);
		businessException = new BusinessException(new Throwable(), businessError, "phase");
		assertEquals(businessException.getMessage(), "FAH - Erreur lors de l appel vers l API CRF");
		assertEquals(businessException.getPhase(), "phase");
		assertEquals(businessException.getName(), "ERROR_CALL_API_CFR");
	}
	
	@Test
	void testWithBusineddError() {
		var message = CFR_CALL_ERROR_CODE;
		BusinessError businessError = new BusinessError(message);
		businessException = new BusinessException(businessError, "phase");
		assertEquals(businessException.getMessage(), "FAH - Erreur lors de l appel vers l API CRF");
		assertEquals(businessException.getPhase(), "phase");
		assertEquals(businessException.getName(), "ERROR_CALL_API_CFR");
	}

}
