package fr.bpifrance.fah.statusperf.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import fr.bpifrance.fah.statusperf.common.exceptions.BusinessError;

class BusinessErrorTest {

	private BusinessError businessError = null;

	private final String CFR_CALL_ERROR_CODE = "fah.cfr.api";

	@Test
	void testBusinessErrorString() {
		var message = CFR_CALL_ERROR_CODE;
		businessError = new BusinessError(message, "file.txt");
		var expected = "FAH - Erreur lors de l appel vers l API CRF";
		assertEquals(expected, businessError.getMessage());
	}
	
	@Test
	void testBusinessError() {
		var message = CFR_CALL_ERROR_CODE;
		businessError = new BusinessError(message);
		var expectedMsg = "FAH - Erreur lors de l appel vers l API CRF";
		var expectedType = "TECHNIQUE";
		var expectedCode = "ERROR_CALL_API_CFR";
		assertEquals(expectedMsg, businessError.getMessage());
		assertEquals(expectedType, businessError.getType());
		assertEquals(expectedCode, businessError.getCode());
	}

	@Test
	void testBusinessErrorString2() {
		try {
			businessError = new BusinessError(null);
		} catch (RuntimeException e) {
		}
		assertNull(businessError.getMessage());
	}


	@Test
	void testBusinessErrorStringObjectArray2() {
		try {
			var fieldName = "fieldName";
			businessError = new BusinessError(null, fieldName);
		} catch (RuntimeException e) {
		}
		assertNull(businessError.getMessage());
	}

}
