package fr.bpifrance.fah.statusperf.infrastructure.cfr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import fr.bpifrance.fah.statusperf.infrastructure.cfr.dto.StockDto;

@ExtendWith(MockitoExtension.class)
public class CfrApiRestClientTest {

	@Mock
	private CfrApiRestClient cfrApiRestClient;

	@Test
	void getStockReturnsStockDtoForValidDate() {
		StockDto expectedStockDto = new StockDto();
		when(cfrApiRestClient.getStock("2023-10-10")).thenReturn(expectedStockDto);

		StockDto actualStockDto = cfrApiRestClient.getStock("2023-10-10");

		assertEquals(expectedStockDto, actualStockDto);
	}

	@Test
	void getStockThrowsExceptionForInvalidDate() {
		when(cfrApiRestClient.getStock("invalid-date")).thenThrow(new RuntimeException("Invalid date format"));

		assertThrows(RuntimeException.class, () -> cfrApiRestClient.getStock("invalid-date"));
	}

	@Test
	void getStockHandlesNullDate() {
		when(cfrApiRestClient.getStock(null)).thenThrow(new RuntimeException("Date cannot be null"));

		assertThrows(RuntimeException.class, () -> cfrApiRestClient.getStock(null));
	}

	@Test
	void getStockHandlesEmptyDate() {
		when(cfrApiRestClient.getStock("")).thenThrow(new RuntimeException("Date cannot be empty"));

		assertThrows(RuntimeException.class, () -> cfrApiRestClient.getStock(""));
	}

}
