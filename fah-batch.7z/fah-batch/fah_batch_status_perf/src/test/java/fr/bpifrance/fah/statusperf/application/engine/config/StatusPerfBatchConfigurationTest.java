package fr.bpifrance.fah.statusperf.application.engine.config;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

import javax.sql.DataSource;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.support.JdbcTransactionManager;

public class StatusPerfBatchConfigurationTest {
	StatusPerfBatchConfiguration config = new StatusPerfBatchConfiguration();

    @Test
    void batchDataSourceReturnsNonNullDataSource() {
        DataSource dataSource = config.batchDataSource();
        assertNotNull(dataSource);
    }

    @Test
    void batchTransactionManagerReturnsNonNullTransactionManager() {
        DataSource mockDataSource = mock(DataSource.class);
        JdbcTransactionManager transactionManager = config.batchTransactionManager(mockDataSource);
        assertNotNull(transactionManager);
    }

    @Test
    void propertySourcesPlaceholderConfigurerReturnsNonNullConfigurer() {
        assertNotNull(StatusPerfBatchConfiguration.propertySourcesPlaceholderConfigurer());
    }
}
