package fr.bpifrance.fah.statusperf;

import java.net.URL;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.batch.test.JobRepositoryTestUtils;
import org.springframework.batch.test.context.SpringBatchTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignAutoConfiguration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import fr.bpifrance.fah.statusperf.application.engine.config.StatusPerfJobConfiguration;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.CfrApiRestClient;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.dto.StockDto;
import lombok.val;

@SpringBootTest
@SpringBatchTest
@SpringJUnitConfig(classes = { JobStatusPerfTestConfig.class, StatusPerfJobConfiguration.class })
@ActiveProfiles(value = "test")
@EnableFeignClients
@EnableAsync
@ImportAutoConfiguration(FeignAutoConfiguration.class)
@EnableScheduling
public class JobStatusPerfIntegrationTests {

    @MockitoBean
	private CfrApiRestClient cfrApiRestClient;
    
	@Autowired
	@InjectMocks
	private JobLauncherTestUtils jobLauncherTestUtils;

	@Autowired
	private JobRepositoryTestUtils jobRepositoryTestUtils;

    



	private JobParameters defaultJobParameters() {
		val paramsBuilder = new JobParametersBuilder();
		paramsBuilder.addDate("timestamp", Calendar.getInstance().getTime());
		return paramsBuilder.toJobParameters();
	}
	
    @AfterEach
    public void cleanUp() {
        jobRepositoryTestUtils.removeJobExecutions();
    }

	@Test
	public void testJob(@Autowired Job job) throws Exception {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
		StockDto stock = new StockDto();
		URL testUrl = Paths.get("src/test/resources/data",("STATUS_PERF_19122024.csv")).toUri().toURL();
		stock.setFileUrl("file://" + testUrl.getPath());
		LocalDate date = LocalDate.now().minusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
		Mockito.when(cfrApiRestClient.getStock(date.format(formatter)))
		.thenReturn(stock);
		this.jobLauncherTestUtils.setJob(job);
		// when
		val jobExecution = jobLauncherTestUtils.launchJob(defaultJobParameters());

		// then

		Assertions.assertEquals("COMPLETED", jobExecution.getExitStatus().getExitCode());
	}
}
