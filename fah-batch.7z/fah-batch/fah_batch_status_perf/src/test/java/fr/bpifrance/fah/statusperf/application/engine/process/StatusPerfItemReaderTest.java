package fr.bpifrance.fah.statusperf.application.engine.process;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;

import fr.bpifrance.fah.statusperf.application.engine.process.reader.StatusPerfItemReader;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.CfrApiRestClient;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.dto.StockDto;

public class StatusPerfItemReaderTest {
    private CfrApiRestClient mockCfrApiRestClient;
    private StatusPerfItemReader reader;
    private StepContribution mockStepContribution;
    private ChunkContext mockChunkContext;

    @BeforeEach
    void setUp() {
        mockCfrApiRestClient = mock(CfrApiRestClient.class);
        reader = new StatusPerfItemReader(mockCfrApiRestClient, "/tmp/", "0 0 12 * * ?");
        mockStepContribution = mock(StepContribution.class);
        mockChunkContext = mock(ChunkContext.class);
    }

    @Test
    void getTargetDirectoryReturnsCorrectPath() {
        assertNotNull(reader.getTargetDirectory());
    }

    @Test
    void getFileNameThrowsExceptionForInvalidCronExpression() {
        StatusPerfItemReader readerWithInvalidCron = new StatusPerfItemReader(mockCfrApiRestClient, "/nas/", "invalid-cron");
    }

    @Test
    void validateUrlThrowsExceptionForExternalHost() {
        assertThrows(MalformedURLException.class, () -> reader.validateUrl("http://external.com/test.csv"));
    }

    @Test
    void validateUrlReturnsUrlForInternalHost() throws MalformedURLException {
        assertNotNull(reader.validateUrl("http://bpi-fr/test.csv"));
    }

    @Test
    void executeThrowsExceptionWhenFileUrlIsInvalid() throws Exception {
        StockDto mockStockDto = mock(StockDto.class);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
		LocalDate date = LocalDate.now().minusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
        when(mockCfrApiRestClient.getStock(date.format(formatter))).thenReturn(mockStockDto);
        when(mockStockDto.getFileUrl()).thenReturn("http://external.com/test.csv");

        assertThrows(MalformedURLException.class, () -> reader.execute(mockStepContribution, mockChunkContext));
    }

}
