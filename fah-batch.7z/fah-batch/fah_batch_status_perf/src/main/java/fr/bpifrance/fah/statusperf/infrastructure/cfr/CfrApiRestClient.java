package fr.bpifrance.fah.statusperf.infrastructure.cfr;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import fr.bpifrance.fah.statusperf.infrastructure.cfr.config.CfrApiRestClientConfiguration;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.dto.StockDto;


@FeignClient(name = "cfrapi", url = "${ws.rest.cfrapi.url}", configuration = CfrApiRestClientConfiguration.class)
public interface CfrApiRestClient {
	
	@GetMapping(value = "party/performance-status-np/stock")
	StockDto getStock(@RequestParam String eventdate);

}
