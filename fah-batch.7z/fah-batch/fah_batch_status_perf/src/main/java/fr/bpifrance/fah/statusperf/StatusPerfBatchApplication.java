package fr.bpifrance.fah.statusperf;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.EnableAsync;

import fr.bpifrance.fah.statusperf.application.engine.config.StatusPerfJobRunnerConfiguration;

/**
 * @author M03935
 */
@SpringBootApplication
@EnableFeignClients
@Profile({"local"})
@EnableBatchProcessing
@EnableAsync
@lombok.Generated
public class StatusPerfBatchApplication implements CommandLineRunner {

	@Autowired
    private StatusPerfJobRunnerConfiguration statusPerfJobRunnerConfiguration;

    public static void main(String[] args) {
        SpringApplication.run(StatusPerfBatchApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
    	statusPerfJobRunnerConfiguration.runStatusPerfJob();
    }
    
    
}
