package fr.bpifrance.fah.statusperf.domain.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import lombok.experimental.UtilityClass;

@UtilityClass
public final class FileUtils {


	public static Path createDirectories(final Path dir, final String permissions) throws IOException {
		Objects.requireNonNull(dir);
		Objects.requireNonNull(permissions);

		final Path realDir = dir.toAbsolutePath();
		final Set<PosixFilePermission> perms = PosixFilePermissions.fromString(permissions);

		doCreateDirectories(realDir, perms);

		return dir;
	}

	private static void doCreateDirectories(final Path realDir, final Set<PosixFilePermission> perms)
			throws IOException {
		final List<Path> created = new ArrayList<>();

		Path parent = realDir;

		while (parent != null && !Files.exists(parent)) {
			created.add(parent);
			parent = parent.getParent();
		}

		Files.createDirectories(realDir); //NOSONAR

		for (final Path path : created) {
			Files.setPosixFilePermissions(path, perms);//NOSONAR
		}
	}

	public static Path createFile(final Path path, final String permissions) throws IOException {
		Objects.requireNonNull(path);
		Objects.requireNonNull(permissions);

		final Set<PosixFilePermission> perms = PosixFilePermissions.fromString(permissions);

		return doCreateFile(path, perms);
	}

	private static Path doCreateFile(final Path path, final Set<PosixFilePermission> perms) throws IOException {
		Files.createFile(path);//NOSONAR
		return Files.setPosixFilePermissions(path, perms);//NOSONAR
	}
	
	public static void delete(final Path path) throws IOException {
		Files.delete(path);
	}

}
