package fr.bpifrance.fah.statusperf.infrastructure.cfr.interceptors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;

import feign.RequestTemplate;
import fr.bpifrance.fah.statusperf.infrastructure.isam.interceptors.CommonClientInterceptor;
import fr.bpifrance.fah.statusperf.infrastructure.isam.model.IsamAccessToken;

public class CfrApiRestClientJWTInterceptor extends CommonClientInterceptor {

	private static final String TOKEN_TYPE = "Bearer ";
	private static final String HEADER_TYK_SLM_CLIENT_ID = "x-api-key";
	private static final String HEADER_SLM_CONTENT_TYPE = "application/json";
	private static final Logger LOGGER = LoggerFactory.getLogger(CfrApiRestClientJWTInterceptor.class);

	@Value("${tyk.x-api-key}")
	private String tykXApiKey;
	
	@Override
	public void modifierRequestHeader(RequestTemplate requestTemplate, IsamAccessToken isamAccessToken) {
		if (isamAccessToken != null) {
			requestTemplate.header(HttpHeaders.AUTHORIZATION, TOKEN_TYPE + isamAccessToken.getAccessToken());
			requestTemplate.header(HEADER_TYK_SLM_CLIENT_ID, tykXApiKey);
			requestTemplate.header(HttpHeaders.CONTENT_TYPE, HEADER_SLM_CONTENT_TYPE);
		} else {
			LOGGER.warn(">>>>> Isam est UP mais ne renvoie pas d'access token (valeur null)");
		}

	}
}
