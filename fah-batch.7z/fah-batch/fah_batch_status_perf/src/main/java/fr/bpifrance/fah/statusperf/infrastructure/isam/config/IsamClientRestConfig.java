package fr.bpifrance.fah.statusperf.infrastructure.isam.config;

import org.springframework.context.annotation.Bean;

import feign.codec.Encoder;
import feign.form.FormEncoder;

/**
 * @author M35878
 */
public class IsamClientRestConfig {

	@Bean
	public Encoder encoder() {
		return new FormEncoder();
	}

}
