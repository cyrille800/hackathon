package fr.bpifrance.fah.statusperf.application.engine.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.PlatformTransactionManager;

import fr.bpifrance.fah.statusperf.application.engine.process.listener.StatusPerfJobExecutionListenner;
import fr.bpifrance.fah.statusperf.application.engine.process.reader.StatusPerfItemReader;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.CfrApiRestClient;

/**
 * @author M03935
 */
public class StatusPerfJobConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(StatusPerfJobConfiguration.class);
    
    public static final String JOB_NAME = "statusperf-job";

    @Value("${nas.name}")
    private String nasName;

    @Value("${batch.chunk.size}")
    private String chunkSize;
    
    @Value("${cron.expressionCfr}")
    private String cronExpressionCfr;
    
	@Autowired
	private CfrApiRestClient cfrApiRestClient;


    @Bean
    public Job job(JobRepository jobRepository, Step step) {
        logger.info("Creating job with name 'statusperf-job'");
        return new JobBuilder("statusperf-job", jobRepository)
                .start(step)
                .listener(jobExecutionListener())
                .build();
    }

    @Bean
    public Step step(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("processLines", jobRepository)
                .tasklet(itemReader(), transactionManager)
                .build();
    }

    @Bean
    public StatusPerfItemReader itemReader() {
        return new StatusPerfItemReader(cfrApiRestClient, nasName, cronExpressionCfr);
    }
    
    @Bean
    public JobExecutionListener jobExecutionListener() {
        return new StatusPerfJobExecutionListenner();
    }

}
