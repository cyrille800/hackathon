package fr.bpifrance.fah.statusperf.application.engine.process.listener;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

public class StatusPerfJobExecutionListenner implements JobExecutionListener {

	@Override
	public void afterJob(JobExecution jobExecution) {
		ExitStatus exitStatus = jobExecution.getExitStatus();
		if (exitStatus.getExitCode().equals(ExitStatus.FAILED.getExitCode())) {
			System.exit(1);
		}
	}
}
