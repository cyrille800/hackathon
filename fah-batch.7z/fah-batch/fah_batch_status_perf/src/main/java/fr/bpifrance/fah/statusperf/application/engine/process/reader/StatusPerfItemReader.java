package fr.bpifrance.fah.statusperf.application.engine.process.reader;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.scheduling.support.CronExpression;

import fr.bpifrance.fah.statusperf.common.exceptions.BusinessError;
import fr.bpifrance.fah.statusperf.common.exceptions.BusinessException;
import fr.bpifrance.fah.statusperf.domain.utils.FileUtils;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.CfrApiRestClient;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.dto.StockDto;

/**
 * @author M03935
 */
public class StatusPerfItemReader implements Tasklet {

	private static final Logger logger = LoggerFactory.getLogger(StatusPerfItemReader.class);

	private CfrApiRestClient cfrApiRestClient;

	private String nasName;

	private String cronExpressionCfr;

	public StatusPerfItemReader(CfrApiRestClient cfrApiRestClient, String nasName, String cronExpressionCfr) {
		this.cfrApiRestClient = cfrApiRestClient;
		this.nasName = nasName;
		this.cronExpressionCfr = cronExpressionCfr;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
		LocalDate date = LocalDate.now().minusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
		StockDto stock = cfrApiRestClient.getStock(date.format(formatter));
		logger.info("FAH CALL CFR API SUCCESS");
		String targetDirectory = this.getTargetDirectory();
		Path directoryPath = Paths.get(targetDirectory); // NOSONAR
		FileUtils.createDirectories(directoryPath, "rwxrwxrwx");
		var fileName = getFileName("STATUS_DE_PERF_");
		Path filePath = Paths.get(targetDirectory + fileName).toAbsolutePath().normalize(); // NOSONAR
		if (Files.exists(filePath)) {
			FileUtils.delete(filePath);
		}
		FileUtils.createFile(filePath, "rwxrwxrwx");
		URL fileUrl = validateUrl(stock.getFileUrl());
		InputStream in = fileUrl.openStream(); // NOSONAR
		Files.copy(in, filePath, StandardCopyOption.REPLACE_EXISTING);
		logger.info("FAH DOWNLOAD STATUS DE PERF FILE SUCCESS");
		
		return RepeatStatus.FINISHED;
	}

	public String getTargetDirectory() {
		return this.nasName + "status-de-performance/";
	}

	public String getFileName(String fileNamePrefix) {

		var localDateTime = LocalDateTime.now().minusMonths(1);
		var cronTrigger = CronExpression.parse(cronExpressionCfr);
		var nextDateTime = cronTrigger.next(localDateTime);
		if (nextDateTime == null) {
			throw new BusinessException(new BusinessError("ais.rw-name-file.error"), "TECH_READ_FILE_ERROR");
		}

		return fileNamePrefix + nextDateTime.format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".csv";
	}

	public URL validateUrl(String urlString) throws MalformedURLException {
		URL url = new URL(urlString);
		String host = url.getHost();
		if (!isInternalHost(host)) {
			throw new MalformedURLException("URL points to an internal host");
		}
		return url;
	}

	private boolean isInternalHost(String host) {
		return host.startsWith("bpi-fr") || host.isEmpty();
	}

}
