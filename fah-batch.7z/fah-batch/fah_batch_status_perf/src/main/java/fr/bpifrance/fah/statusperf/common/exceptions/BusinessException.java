package fr.bpifrance.fah.statusperf.common.exceptions;

import java.io.Serializable;

public class BusinessException extends RuntimeException implements Serializable {

	private static final long serialVersionUID = 3221244520800071962L;

	private final String phase;
	private final BusinessError businessError;
	
	public BusinessException(Throwable throwable,BusinessError businessError, String phase) {
		super(throwable);
		this.phase = phase;
		this.businessError = businessError;
	}

	public BusinessException(BusinessError businessError,String phase) {
		super();
		this.phase = phase;
		this.businessError = businessError;
	}

	
	public String getPhase() {
		return phase;
	}

	@Override
	public String getMessage() {
		return this.businessError.getMessage();
	}

	public String getName() {
		return  this.businessError.getCode();
	}

}
