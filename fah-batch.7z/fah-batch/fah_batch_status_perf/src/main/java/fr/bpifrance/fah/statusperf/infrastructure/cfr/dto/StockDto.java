package fr.bpifrance.fah.statusperf.infrastructure.cfr.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockDto {

    @JsonProperty("file_url")
    public String fileUrl;

    @JsonProperty("information")
    public String information;

}
