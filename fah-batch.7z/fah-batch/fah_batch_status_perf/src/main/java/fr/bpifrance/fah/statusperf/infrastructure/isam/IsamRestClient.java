package fr.bpifrance.fah.statusperf.infrastructure.isam;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import fr.bpifrance.fah.statusperf.infrastructure.isam.config.IsamClientRestConfig;
import fr.bpifrance.fah.statusperf.infrastructure.isam.model.IsamAccessToken;

/**
 * @author M03935
 */
@FeignClient(name = "isam-client", url = "${isam.url}", configuration = IsamClientRestConfig.class)
public interface IsamRestClient {

	/**
	 * @param form
	 * @return
	 */
	@PostMapping(produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	ResponseEntity<IsamAccessToken> retrieveAccessToken(@RequestBody Map<String, ?> form);
}
