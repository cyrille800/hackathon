package fr.bpifrance.fah.statusperf.infrastructure.isam.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

/***
 * @author M03935
 */
@Getter
public class IsamAccessToken {

	@JsonProperty("access_token")
	private String accessToken;

}
