package fr.bpifrance.fah.statusperf.infrastructure.cfr.config;

import org.springframework.context.annotation.Bean;

import fr.bpifrance.fah.statusperf.infrastructure.cfr.interceptors.CfrApiRestClientJWTInterceptor;

public class CfrApiRestClientConfiguration {

	@Bean
	public CfrApiRestClientJWTInterceptor cfrRestClientJWTInterceptor() {
		return new CfrApiRestClientJWTInterceptor();
	}

}
