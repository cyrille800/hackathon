package fr.bpifrance.fah.statusperf.infrastructure.isam.service.api;

import fr.bpifrance.fah.statusperf.infrastructure.isam.model.IsamAccessToken;

public interface IsamService {
	IsamAccessToken retrieveAccessToken();
}
