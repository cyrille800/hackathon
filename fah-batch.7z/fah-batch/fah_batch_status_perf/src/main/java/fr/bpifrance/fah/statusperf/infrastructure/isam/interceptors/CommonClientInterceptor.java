package fr.bpifrance.fah.statusperf.infrastructure.isam.interceptors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import fr.bpifrance.fah.statusperf.infrastructure.isam.model.IsamAccessToken;
import fr.bpifrance.fah.statusperf.infrastructure.isam.service.api.IsamService;

public abstract class CommonClientInterceptor implements RequestInterceptor {
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonClientInterceptor.class);

	@Autowired
	private IsamService isamService;

	@Override
	public void apply(RequestTemplate template) {

		var isamAccessToken = isamService.retrieveAccessToken();

		modifierRequestHeader(template, isamAccessToken);
		LOGGER.info("REQUEST HEADERS  ::::::: {}", template.headers().get(HttpHeaders.AUTHORIZATION));

	}

	/**
	 * @param requestTemplate
	 * @param IsamAccessToken
	 * @return
	 */
	public abstract void modifierRequestHeader(RequestTemplate requestTemplate, IsamAccessToken isamAccessToken);

}
