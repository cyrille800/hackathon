package fr.bpifrance.fah.statusperf.infrastructure.isam.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import fr.bpifrance.fah.statusperf.common.exceptions.IsamCallException;
import fr.bpifrance.fah.statusperf.infrastructure.isam.IsamRestClient;
import fr.bpifrance.fah.statusperf.infrastructure.isam.model.IsamAccessToken;
import fr.bpifrance.fah.statusperf.infrastructure.isam.service.api.IsamService;

@Service
public class IsamServiceImpl implements IsamService {

	@Value("${isam.clientId}")
	private String isamClientId;

	@Value("${isam.clientSecret}")
	private String isamClientSecret;

	@Value("${isam.grantType}")
	private String grantType;

	@Autowired
	private IsamRestClient isamRestClient;


	private static final Logger LOGGER = LoggerFactory.getLogger(IsamServiceImpl.class);

	@Cacheable(value = "isam-token", unless = "#result == null")
	public IsamAccessToken retrieveAccessToken() {
		final Map<String, String> form = new HashMap<>();
		form.put("grant_type", grantType);
		form.put("client_id", isamClientId);
		form.put("client_secret", isamClientSecret);
		form.put("scope", "openid");
		IsamAccessToken isamAccessToken = null;
		try {
			final ResponseEntity<IsamAccessToken> accessTokenResponseEntity = isamRestClient.retrieveAccessToken(form);
			isamAccessToken = accessTokenResponseEntity.getBody();
			if (isamAccessToken != null) {
				return isamAccessToken;
			}
		} catch (Exception exception) {
			var isamException = new IsamCallException("Erreur lors de l'appel a ISAM pour recuperer l'access token", exception);
			LOGGER.error(">>>>> Erreur lors de l'appel a ISAM pour recuperer l'access token ::: {}", isamException.getMessage());
			LOGGER.error(exception.getMessage());
		}
		return isamAccessToken;
	}

}
