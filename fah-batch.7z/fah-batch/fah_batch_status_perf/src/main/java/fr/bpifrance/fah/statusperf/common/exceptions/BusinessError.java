package fr.bpifrance.fah.statusperf.common.exceptions;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;


public class BusinessError implements Serializable {

	private static final long serialVersionUID = -3745286334398354982L;

	private String code;

	private String type;

	private String message;

	private final transient ResourceBundle resourceBundle = ResourceBundle.getBundle("errors/messages", Locale.FRANCE);

	public BusinessError(final String message) {
		try {
			this.code = resourceBundle.getString(message + ".code");
			this.type = resourceBundle.getString(message + ".type");
			this.message = resourceBundle.getString(message + ".msg");

		} catch (MissingResourceException e) {
			this.message = message;
		}
	}

	public BusinessError(final String message, Object... param) {
		try {
			this.code = resourceBundle.getString(message + ".code");
			this.type = resourceBundle.getString(message + ".type");
			this.message = MessageFormat.format(resourceBundle.getString(message + ".msg"), param);

		} catch (MissingResourceException e) {
			this.message = message;
		}

	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return String.format("BusinessError {message=%s, code=%s, type=%s}", message, code, type);
	}
}
