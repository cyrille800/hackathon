package fr.bpifrance.fah.cslm.domain.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PcctPerCompaCtgModel {


	private String nomLivre;

	private Integer perCompta;

	private Integer anPerCompta;
	

	private Integer moisPerCompta;

	private String debPerCompta;

	private String finPerCompta;

	private String sttPerCompta;
	
	
	
	
}
