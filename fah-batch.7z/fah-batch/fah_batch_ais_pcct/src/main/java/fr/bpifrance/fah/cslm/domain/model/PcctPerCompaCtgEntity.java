package fr.bpifrance.fah.cslm.domain.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Setter;

@Setter
@Entity
@Table(name = "PCCT_PER_COMPTA_CTG")
@IdClass(PCCTClassId.class)
public class PcctPerCompaCtgEntity {

	
	@Id
    @Column(name = "V_NOM_LIVRE")
	private String nomLivre;

	@Id
    @Column(name = "N_PER_COMPTA")
	private Integer perCompta;

	@Id
    @Column(name = "N_AN_PER_COMPTA")
	private Integer anPerCompta;
	
    @Column(name = "N_MOIS_PER_COMPTA")
	private Integer moisPerCompta;
	
    @Column(name = "D_DEB_PER_COMPTA")
	private LocalDate debPerCompta;
	
    @Column(name = "D_FIN_PER_COMPTA")
	private LocalDate finPerCompta;
	
    @Column(name = "C_STT_PER_COMPTA")
	private String sttPerCompta;
	
	
	
	
}
