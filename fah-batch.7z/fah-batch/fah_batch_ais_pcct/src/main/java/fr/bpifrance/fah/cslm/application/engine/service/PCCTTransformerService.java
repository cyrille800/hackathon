package fr.bpifrance.fah.cslm.application.engine.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import fr.bpifrance.fah.cslm.domain.model.PcctPerCompaCtgEntity;
import fr.bpifrance.fah.cslm.domain.model.PcctPerCompaCtgModel;

/**
 * @author M03935
 */
@Service
public class PCCTTransformerService {

    private static final Logger logger = LogManager.getLogger(PCCTTransformerService.class);


    /**
     * @return the transformed PcctPerCompaCtgEntity
     */
    public PcctPerCompaCtgEntity transform(PcctPerCompaCtgModel input) {
        final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        PcctPerCompaCtgEntity res = new PcctPerCompaCtgEntity();
        res.setNomLivre(input.getNomLivre());
        res.setPerCompta(input.getPerCompta());
        res.setAnPerCompta(input.getAnPerCompta());
        res.setMoisPerCompta(input.getMoisPerCompta());
        res.setDebPerCompta(LocalDate.parse(input.getDebPerCompta(),dtf)); 
        res.setFinPerCompta(LocalDate.parse(input.getFinPerCompta(),dtf));
        res.setSttPerCompta(input.getSttPerCompta());
        return res;
    }
}