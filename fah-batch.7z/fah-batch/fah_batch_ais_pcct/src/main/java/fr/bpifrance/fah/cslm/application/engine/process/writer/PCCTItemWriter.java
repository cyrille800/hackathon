package fr.bpifrance.fah.cslm.application.engine.process.writer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;

import fr.bpifrance.fah.cslm.application.engine.process.processor.PCCTItemProcessor;
import fr.bpifrance.fah.cslm.domain.model.PcctPerCompaCtgEntity;
import fr.bpifrance.fah.cslm.domain.repository.PcctPerCompaCtgRepository;

/**
 * @author M03935
 */
public class PCCTItemWriter implements ItemWriter<PcctPerCompaCtgEntity> {
	
    private static final Logger logger = LoggerFactory.getLogger(PCCTItemProcessor.class);

	private PcctPerCompaCtgRepository repository;

    public PCCTItemWriter(PcctPerCompaCtgRepository repository) {
    	this.repository =  repository;
    }


    @Override
    public void write(Chunk<? extends PcctPerCompaCtgEntity> items) throws Exception {
   		 repository.saveAll(items);
    }

}
