package fr.bpifrance.fah.cslm.application.engine.process.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import fr.bpifrance.fah.cslm.application.engine.service.PCCTTransformerService;
import fr.bpifrance.fah.cslm.domain.model.PcctPerCompaCtgEntity;
import fr.bpifrance.fah.cslm.domain.model.PcctPerCompaCtgModel;

/**
 * @author M03935
 */
public class PCCTItemProcessor implements ItemProcessor<PcctPerCompaCtgModel, PcctPerCompaCtgEntity>{

    private static final Logger logger = LoggerFactory.getLogger(PCCTItemProcessor.class);

    private final PCCTTransformerService transformService;

    public PCCTItemProcessor(PCCTTransformerService transformService) {
        this.transformService = transformService;
    }


    @Override
    public PcctPerCompaCtgEntity process(PcctPerCompaCtgModel input) {
        try {
            PcctPerCompaCtgEntity transformedInput = transformService.transform(input);
            return transformedInput;
        } catch (Exception e) {
            logger.error("Error processing line: {}", input, e);
            throw new RuntimeException("Error processing line: " + input, e);
        }
    }

}
