package fr.bpifrance.fah.cslm;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Profile;

import fr.bpifrance.fah.cslm.application.engine.config.PCCTJobRunnerConfiguration;

/**
 * @author M03935
 */
@SpringBootApplication
@Profile({"local"})
@EnableBatchProcessing
@lombok.Generated
public class PCCTBatchApplication implements CommandLineRunner {

    @Autowired
    private PCCTJobRunnerConfiguration pcctJobRunner;

    public static void main(String[] args) {
        SpringApplication.run(PCCTBatchApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
    	pcctJobRunner.runPCCTJob();
    }
}
