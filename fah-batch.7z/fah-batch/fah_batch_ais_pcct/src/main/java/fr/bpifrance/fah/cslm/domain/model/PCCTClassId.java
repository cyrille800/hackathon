package fr.bpifrance.fah.cslm.domain.model;

import java.util.Objects;

public class PCCTClassId {

	private String nomLivre;

	private Integer perCompta;

	private Integer anPerCompta;

	public PCCTClassId() {
	}

	public PCCTClassId(String nomLivre, Integer perCompta, Integer anPerCompta) {
		this.nomLivre = nomLivre;
		this.perCompta = perCompta;
		this.anPerCompta = anPerCompta;
	}

	@Override
	public int hashCode() {
		return Objects.hash(anPerCompta, nomLivre, perCompta);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PCCTClassId other = (PCCTClassId) obj;
		return Objects.equals(anPerCompta, other.anPerCompta) && Objects.equals(nomLivre, other.nomLivre)
				&& Objects.equals(perCompta, other.perCompta);
	}
}
