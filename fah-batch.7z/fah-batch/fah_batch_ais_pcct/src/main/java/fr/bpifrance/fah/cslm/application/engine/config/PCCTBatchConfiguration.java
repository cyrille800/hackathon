package fr.bpifrance.fah.cslm.application.engine.config;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.batch.BatchDataSource;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariDataSource;

/**
 * @author M03935
 */
@Configuration
@Profile({ "local", "pcct"})
@ComponentScan(basePackages = { "fr.bpifrance.fah.pcct" })
@EnableTransactionManagement
@EntityScan("fr.bpifrance.fah.pcct.*")
@EnableJpaRepositories("fr.bpifrance.fah.pcct.*")
@Import({ PCCTJobConfiguration.class, PCCTJobRunnerConfiguration.class })
public class PCCTBatchConfiguration {

	@Bean(name = "dataSource")
	@BatchDataSource
	public DataSource H2Datasource() {
        return new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.HSQL)
                .addScript("/org/springframework/batch/core/schema-hsqldb.sql")
                .generateUniqueName(true).build();

	}

	@Bean
	@Primary
	@ConfigurationProperties("spring.datasource")
	public DataSourceProperties oracleDatasourceProperties() {
		return new DataSourceProperties();
	}

	@Bean
	@Primary
	@ConfigurationProperties("spring.datasource.hikari")
	public DataSource oracleDatasource() {
		return oracleDatasourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

}
