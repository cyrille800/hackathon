package fr.bpifrance.fah.cslm.application.engine.process.reader;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import fr.bpifrance.fah.cslm.domain.model.PcctPerCompaCtgModel;

public class PcctFieldSetMapper implements FieldSetMapper<PcctPerCompaCtgModel> {

	@Override
	public PcctPerCompaCtgModel mapFieldSet(FieldSet fieldSet) throws BindException {
		PcctPerCompaCtgModel res = new PcctPerCompaCtgModel();
		res.setNomLivre(fieldSet.readString(0));
		res.setPerCompta(fieldSet.readInt(1));
		res.setAnPerCompta(fieldSet.readInt(2));
		res.setMoisPerCompta(fieldSet.readInt(3));
		res.setDebPerCompta(fieldSet.readString(4));
		res.setFinPerCompta(fieldSet.readString(5));
		res.setSttPerCompta(fieldSet.readString(6));
		return res;
	}

}
