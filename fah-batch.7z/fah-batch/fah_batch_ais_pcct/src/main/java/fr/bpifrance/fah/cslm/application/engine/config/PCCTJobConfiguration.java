package fr.bpifrance.fah.cslm.application.engine.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;

import fr.bpifrance.fah.cslm.application.engine.process.listener.PCCTJobExecutionListenner;
import fr.bpifrance.fah.cslm.application.engine.process.processor.PCCTItemProcessor;
import fr.bpifrance.fah.cslm.application.engine.process.reader.PCCTItemReader;
import fr.bpifrance.fah.cslm.application.engine.process.writer.PCCTItemWriter;
import fr.bpifrance.fah.cslm.application.engine.service.PCCTTransformerService;
import fr.bpifrance.fah.cslm.domain.model.PcctPerCompaCtgEntity;
import fr.bpifrance.fah.cslm.domain.model.PcctPerCompaCtgModel;
import fr.bpifrance.fah.cslm.domain.repository.PcctPerCompaCtgRepository;

/**
 * @author M80889
 */
public class PCCTJobConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(PCCTJobConfiguration.class);

    @Value("${batch.chunk.size}")
    private String chunkSize;

    @Value("${batch.input.filepath}")
    private String inputFilePath;


    @Autowired
    private PCCTTransformerService transformService;
    
    @Autowired
	private PcctPerCompaCtgRepository repository;

    @Bean
    public Job job(JobRepository jobRepository, Step step) {
        logger.info("Creating job with name 'pcct-job'");
        return new JobBuilder("pcct-job", jobRepository)
                .start(step)
                .listener(jobExecutionListener())
                .build();
    }

    @Bean
    public Step step(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        logger.info("Creating step with chunk size {}", chunkSize);
        return new StepBuilder("step", jobRepository)
                .<PcctPerCompaCtgModel, PcctPerCompaCtgEntity>chunk(Integer.parseInt(chunkSize), transactionManager)
                .reader(itemReader())
                .processor(itemProcessor())
                .writer(itemWriter())
                .build();
    }

    @Bean
    public FlatFileItemReader<PcctPerCompaCtgModel> itemReader() {
        logger.info("Creating item reader for file {}", inputFilePath);
        return new PCCTItemReader(new FileSystemResource(inputFilePath));
    }

    @Bean
    public ItemProcessor<PcctPerCompaCtgModel, PcctPerCompaCtgEntity> itemProcessor() {
        logger.info("Creating item processor");
        return new PCCTItemProcessor(transformService);
    }

    @Bean
    public ItemWriter<PcctPerCompaCtgEntity> itemWriter() {
        logger.info("Creating item writer");
        return new PCCTItemWriter(repository);
    }
    

    @Bean
    public JobExecutionListener jobExecutionListener() {
        return new PCCTJobExecutionListenner();
    }

}
