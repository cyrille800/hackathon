package fr.bpifrance.fah.cslm.domain.model;

	

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class PCCTClassIdTest {

    @Test
    public void equalsWithSameObject() {
        PCCTClassId id1 = new PCCTClassId("Livre1", 1, 2023);
        assertTrue(id1.equals(id1));
    }

    @Test
    public void equalsWithNullObject() {
        PCCTClassId id1 = new PCCTClassId("Livre1", 1, 2023);
        assertFalse(id1.equals(null));
    }

    @Test
    public void equalsWithDifferentClassObject() {
        PCCTClassId id1 = new PCCTClassId("Livre1", 1, 2023);
        String other = "SomeString";
        assertFalse(id1.equals(other));
    }

    @Test
    public void equalsWithEqualObjects() {
        PCCTClassId id1 = new PCCTClassId("Livre1", 1, 2023);
        PCCTClassId id2 = new PCCTClassId("Livre1", 1, 2023);
        assertTrue(id1.equals(id2));
    }

    @Test
    public void equalsWithDifferentNomLivre() {
        PCCTClassId id1 = new PCCTClassId("Livre1", 1, 2023);
        PCCTClassId id2 = new PCCTClassId("Livre2", 1, 2023);
        assertFalse(id1.equals(id2));
    }

    @Test
    public void equalsWithDifferentPerCompta() {
        PCCTClassId id1 = new PCCTClassId("Livre1", 1, 2023);
        PCCTClassId id2 = new PCCTClassId("Livre1", 2, 2023);
        assertFalse(id1.equals(id2));
    }

    @Test
    public void equalsWithDifferentAnPerCompta() {
        PCCTClassId id1 = new PCCTClassId("Livre1", 1, 2023);
        PCCTClassId id2 = new PCCTClassId("Livre1", 1, 2024);
        assertFalse(id1.equals(id2));
    }

    @Test
    public void hashCodeWithEqualObjects() {
        PCCTClassId id1 = new PCCTClassId("Livre1", 1, 2023);
        PCCTClassId id2 = new PCCTClassId("Livre1", 1, 2023);
        assertEquals(id1.hashCode(), id2.hashCode());
    }

    @Test
    public void hashCodeWithDifferentObjects() {
        PCCTClassId id1 = new PCCTClassId("Livre1", 1, 2023);
        PCCTClassId id2 = new PCCTClassId("Livre2", 2, 2024);
        assertNotEquals(id1.hashCode(), id2.hashCode());
    }
}