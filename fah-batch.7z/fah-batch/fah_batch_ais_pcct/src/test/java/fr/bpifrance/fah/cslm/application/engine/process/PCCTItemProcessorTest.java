package fr.bpifrance.fah.cslm.application.engine.process;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import fr.bpifrance.fah.cslm.application.engine.process.processor.PCCTItemProcessor;
import fr.bpifrance.fah.cslm.application.engine.service.PCCTTransformerService;
import fr.bpifrance.fah.cslm.domain.model.PcctPerCompaCtgEntity;
import fr.bpifrance.fah.cslm.domain.model.PcctPerCompaCtgModel;

public class PCCTItemProcessorTest {

    @Mock
    private PCCTTransformerService transformService;

    @InjectMocks
    private PCCTItemProcessor processor;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void processShouldTransformInputSuccessfully() throws Exception {
        PcctPerCompaCtgModel input = new PcctPerCompaCtgModel();
        PcctPerCompaCtgEntity expectedOutput = new PcctPerCompaCtgEntity();
        when(transformService.transform(input)).thenReturn(expectedOutput);

        PcctPerCompaCtgEntity result = processor.process(input);

        assertNotNull(result);
        assertEquals(expectedOutput, result);
    }

    @Test
    public void processShouldThrowRuntimeExceptionOnTransformationError() throws Exception {
        PcctPerCompaCtgModel input = new PcctPerCompaCtgModel();
        when(transformService.transform(input)).thenThrow(new RuntimeException("Transformation error"));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> processor.process(input));

        assertEquals("Error processing line: " + input, exception.getMessage());
    }
}
