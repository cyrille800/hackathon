package fr.bpifrance.fah.cslm;

import java.util.Calendar;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.batch.test.JobRepositoryTestUtils;
import org.springframework.batch.test.context.SpringBatchTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import fr.bpifrance.fah.cslm.application.engine.config.PCCTJobConfiguration;
import lombok.val;

@SpringBootTest
@SpringBatchTest
@SpringJUnitConfig(classes = {JobPCCTestConfig.class, PCCTJobConfiguration.class})
@ActiveProfiles(value = "test")
public class JobPCCTIntegrationTests {
    
    @Autowired
    private JobLauncherTestUtils jobLauncherTestUtils;

    @Autowired
    private JobRepositoryTestUtils jobRepositoryTestUtils;
    
    private JobParameters defaultJobParameters() {
        val paramsBuilder = new JobParametersBuilder();
        paramsBuilder.addString("inputFile", "src/test/resources/AISCTRPE.csv");
        paramsBuilder.addDate("timestamp", Calendar.getInstance().getTime());
        return paramsBuilder.toJobParameters();
    }
    
    @AfterEach
    public void cleanUp() {
        jobRepositoryTestUtils.removeJobExecutions();
    }
    
    @Test
    public void testJob(@Autowired Job job) throws Exception {
    	
    	
        this.jobLauncherTestUtils.setJob(job);
     // when
        val jobExecution = jobLauncherTestUtils.launchJob(defaultJobParameters());

        // then



        Assertions.assertEquals("COMPLETED", jobExecution.getExitStatus().getExitCode());
    }
}
