--------------------------------------------------------
--  Fichier créé - mardi-février-25-2025   
--------------------------------------------------------
-- Impossible d'afficher le langage DDL TABLE pour l'objet PCCT_PER_COMPTA_CTG avec DBMS_METADATA tentant le générateur interne.

CREATE TABLE PCCT_PER_COMPTA_CTG 
(
  V_NOM_LIVRE VARCHAR(30) NOT NULL 
, N_PER_COMPTA BIGINT NOT NULL 
, N_AN_PER_COMPTA BIGINT NOT NULL 
, N_MOIS_PER_COMPTA BIGINT 
, D_DEB_PER_COMPTA DATE 
, D_FIN_PER_COMPTA DATE 
, C_STT_PER_COMPTA VARCHAR(1) 
) ;

ALTER TABLE PCCT_PER_COMPTA_CTG
ADD CONSTRAINT PK_PCCT PRIMARY KEY 
(
  V_NOM_LIVRE 
, N_PER_COMPTA 
, N_AN_PER_COMPTA 
);

