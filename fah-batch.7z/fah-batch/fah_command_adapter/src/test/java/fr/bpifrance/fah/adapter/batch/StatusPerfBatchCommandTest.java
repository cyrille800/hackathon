package fr.bpifrance.fah.adapter.batch;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import fr.bpifrance.fah.statusperf.application.engine.config.StatusPerfJobRunnerConfiguration;

public class StatusPerfBatchCommandTest {

    @Mock
    private StatusPerfJobRunnerConfiguration statusPerfJobRunnerConfiguration;

    @InjectMocks
    private StatusPerfBatchCommand statusPerfBatchCommand;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void executeShouldRunPCCTJobSuccessfully() throws Exception {
        doNothing().when(statusPerfJobRunnerConfiguration).runStatusPerfJob();

        statusPerfBatchCommand.execute();

        verify(statusPerfJobRunnerConfiguration, times(1)).runStatusPerfJob();
    }

    @Test
    public void executeShouldThrowExceptionWhenPCCTJobFails() throws Exception {
        doThrow(new RuntimeException("Job failed")).when(statusPerfJobRunnerConfiguration).runStatusPerfJob();

        Exception exception = assertThrows(Exception.class, () -> statusPerfBatchCommand.execute());

        assertEquals("Job failed", exception.getMessage());
    }
}