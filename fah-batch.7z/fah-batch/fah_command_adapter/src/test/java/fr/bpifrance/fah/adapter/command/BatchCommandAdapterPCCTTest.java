package fr.bpifrance.fah.adapter.command;


import org.junit.jupiter.api.Test;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.test.context.ActiveProfiles;

import fr.bpifrance.fah.adapter.batch.PCCTBatchCommand;


@SpringBootTest(classes = {BatchCommandAdapter.class, BatchCommandRunner.class, PCCTBatchCommand.class})
@ActiveProfiles("pcct")
@ComponentScan("fr.bpifrance.fah.adapter")
@EnableAsync
@EnableBatchProcessing
public class BatchCommandAdapterPCCTTest {

    @Autowired
    private BatchCommandAdapter commandAdapter;

    @Test
    public void testRunBatch() throws Exception {
        String batchName = "pcct";
        commandAdapter.runBatch(batchName);
    }
    
    @Test
    public void testRunNotExistBatch() throws Exception {
        String batchName = "notExistBatch";
        commandAdapter.runBatch(batchName);
    }
}