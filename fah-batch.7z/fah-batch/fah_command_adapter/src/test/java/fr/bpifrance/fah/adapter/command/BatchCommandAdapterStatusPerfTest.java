package fr.bpifrance.fah.adapter.command;


import java.net.URL;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import fr.bpifrance.fah.adapter.batch.PCCTBatchCommand;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.CfrApiRestClient;
import fr.bpifrance.fah.statusperf.infrastructure.cfr.dto.StockDto;


@SpringBootTest(classes = {BatchCommandAdapter.class, BatchCommandRunner.class, PCCTBatchCommand.class})
@ActiveProfiles("statusperf")
@ComponentScan("fr.bpifrance.fah.adapter")
@EnableAsync
@EnableBatchProcessing
public class BatchCommandAdapterStatusPerfTest {

    @MockitoBean
	private CfrApiRestClient cfrApiRestClient;
    
    @Autowired
    private BatchCommandAdapter commandAdapter;

    @Test
    public void testRunBatch() throws Exception {
    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
		StockDto stock = new StockDto();
		URL testUrl = Paths.get("src/test/resources/data/statusperf",("STATUS_PERF_19122024.csv")).toUri().toURL();
		stock.setFileUrl("file://" + testUrl.getPath());
		LocalDate date = LocalDate.now().minusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
		Mockito.when(cfrApiRestClient.getStock(date.format(formatter)))
		.thenReturn(stock);
        String batchName = "statusperf";
        commandAdapter.runBatch(batchName);
    }
    
}