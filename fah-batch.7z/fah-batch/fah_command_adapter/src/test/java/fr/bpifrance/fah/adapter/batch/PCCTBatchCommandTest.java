package fr.bpifrance.fah.adapter.batch;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import fr.bpifrance.fah.cslm.application.engine.config.PCCTJobRunnerConfiguration;

public class PCCTBatchCommandTest {

    @Mock
    private PCCTJobRunnerConfiguration pcctJobRunnerConfiguration;

    @InjectMocks
    private PCCTBatchCommand pcctBatchCommand;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void executeShouldRunPCCTJobSuccessfully() throws Exception {
        doNothing().when(pcctJobRunnerConfiguration).runPCCTJob();

        pcctBatchCommand.execute();

        verify(pcctJobRunnerConfiguration, times(1)).runPCCTJob();
    }

    @Test
    public void executeShouldThrowExceptionWhenPCCTJobFails() throws Exception {
        doThrow(new RuntimeException("Job failed")).when(pcctJobRunnerConfiguration).runPCCTJob();

        Exception exception = assertThrows(Exception.class, () -> pcctBatchCommand.execute());

        assertEquals("Job failed", exception.getMessage());
    }
}
