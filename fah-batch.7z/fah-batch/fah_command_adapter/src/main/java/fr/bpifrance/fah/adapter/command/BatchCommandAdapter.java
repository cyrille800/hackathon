package fr.bpifrance.fah.adapter.command;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.bpifrance.fah.adapter.batch.PCCTBatchCommand;
import fr.bpifrance.fah.adapter.batch.StatusPerfBatchCommand;

/**
 * @author M03935
 */
@Component
public class BatchCommandAdapter {

    private static final Logger logger = LoggerFactory.getLogger(BatchCommandAdapter.class);

    private final Map<String, BatchCommand> commandMap = new HashMap<>();

    @Autowired
    public BatchCommandAdapter(Optional<StatusPerfBatchCommand> statusPerfBatchCommand, Optional<PCCTBatchCommand> pcctBatchCommand) {
    	statusPerfBatchCommand.ifPresent(command -> commandMap.put("statusperf", command));
    	pcctBatchCommand.ifPresent(command -> commandMap.put("pcct", command));
    }

    public void runBatch(String batchName) throws Exception {
        logger.info("Running batch: {}", batchName);
        BatchCommand command = commandMap.get(batchName);
        if (command != null) {
            command.execute();
        } else {
            logger.error("Invalid batch name");
        }
    }
}
