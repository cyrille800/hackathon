package fr.bpifrance.fah.adapter.command;

/**
 * @author M03935
 */
public interface BatchCommand {
    void execute() throws Exception;
}
