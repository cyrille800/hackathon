package fr.bpifrance.fah.adapter.batch;

import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import fr.bpifrance.fah.adapter.command.BatchCommand;
import fr.bpifrance.fah.statusperf.application.engine.config.StatusPerfJobRunnerConfiguration;

/**
 * @author M03935
 */
@Component
@Profile("statusperf")
@EnableFeignClients(basePackages = {"fr.bpifrance.fah"})
@ComponentScan("fr.bpifrance.fah.statusperf")
public class StatusPerfBatchCommand implements BatchCommand {

	private final StatusPerfJobRunnerConfiguration statusPerfJobRunnerConfiguration;

	public StatusPerfBatchCommand(StatusPerfJobRunnerConfiguration statusPerfJobRunnerConfiguration) {
		this.statusPerfJobRunnerConfiguration = statusPerfJobRunnerConfiguration;
	}

	@Override
	public void execute() throws Exception {
		statusPerfJobRunnerConfiguration.runStatusPerfJob();
	}
}