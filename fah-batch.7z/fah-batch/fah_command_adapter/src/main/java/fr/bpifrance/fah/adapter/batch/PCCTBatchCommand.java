package fr.bpifrance.fah.adapter.batch;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import fr.bpifrance.fah.adapter.command.BatchCommand;
import fr.bpifrance.fah.cslm.application.engine.config.PCCTJobRunnerConfiguration;

/**
 * @author M03935
 */
@Component
@Profile("pcct")
@ComponentScan("fr.bpifrance.fah.pcct")
public class PCCTBatchCommand implements BatchCommand {

	private final PCCTJobRunnerConfiguration pcctJobRunnerConfiguration;

	public PCCTBatchCommand(PCCTJobRunnerConfiguration pcctJobRunnerConfiguration) {
		this.pcctJobRunnerConfiguration = pcctJobRunnerConfiguration;
	}

	@Override
	public void execute() throws Exception {
		pcctJobRunnerConfiguration.runPCCTJob();
	}
}