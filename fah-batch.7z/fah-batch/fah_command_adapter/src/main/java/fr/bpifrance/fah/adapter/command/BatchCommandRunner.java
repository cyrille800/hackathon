package fr.bpifrance.fah.adapter.command;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author M03935
 */
@SpringBootApplication
@ComponentScan("fr.bpifrance.fah.adapter")
@EnableAsync
@EnableBatchProcessing
@lombok.Generated
public class BatchCommandRunner {

    private static final Logger logger = LoggerFactory.getLogger(BatchCommandRunner.class);

    @Autowired
    private static BatchCommandAdapter commandAdapter;

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            logger.error("Usage: java -jar adapter.jar jobName=<batchName>");
            System.exit(1);
        }

        String batchName = null;
        for (String arg : args) {
            if (arg.startsWith("jobName=")) {
                batchName = arg.substring("jobName=".length());
                break;
            }
        }

        if (batchName == null) {
            logger.error("Batch name not provided. Usage: java -jar adapter.jar jobName=<batchName>");
            System.exit(1);
        }

        System.setProperty("spring.profiles.active", batchName);

        SpringApplication app = new SpringApplication(BatchCommandRunner.class);
        app.setAdditionalProfiles(batchName.toLowerCase());
        ApplicationContext context = app.run(args);
        BatchCommandAdapter commandAdapter = context.getBean(BatchCommandAdapter.class);

        try {
            commandAdapter.runBatch(batchName);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            System.exit(1);
        }
    }
}
